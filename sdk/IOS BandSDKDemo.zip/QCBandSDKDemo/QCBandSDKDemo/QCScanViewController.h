//
//  QCScanViewController.h
//  QCBandSDKDemo
//
//  Created by steve on 2023/2/28.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface QCScanViewController : UIViewController

@end

NS_ASSUME_NONNULL_END
