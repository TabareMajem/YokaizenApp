//
//  AppDelegate.h
//  QCBandSDKDemo
//
//  Created by steve on 2021/7/3.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow * window;
@end

