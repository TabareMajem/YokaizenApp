###1.QCBandSDK Demo使用说明

1. 搜索设备
2. 点击选中需要连接的设备
3. 点击功能按钮，调用对应的指令

### 2.QCBandSDK说明

- 类说明

  - `QCSDKManager`：用于处理App与设备连接相关
  - `QCSDKCmdCreator`：所有指令接口，指令需按顺序调用，若同时调用，后加入的指令会失败

  



