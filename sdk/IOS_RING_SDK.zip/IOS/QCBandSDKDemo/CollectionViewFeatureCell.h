//
//  CollectionViewFeatureCell.h
//  QCBandSDKDemo
//
//  Created by steve on 2021/7/7.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface CollectionViewFeatureCell : UICollectionViewCell

@property(nonatomic,copy) NSString *featureName;
@end

NS_ASSUME_NONNULL_END
