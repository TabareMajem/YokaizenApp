package com.qcwireless.sdksample

/***
 * {"binUrl":"http://api2.qcwxkjvip.com/download/watchface/320X380_COM/04ac774bccd5657f.di","hardwareVersion":"R5_V1.0","name":"04ac774bccd5657f.di","preImageUrl":"http://api2.qcwxkjvip.com/download/watchface/320X380_COM/04ac774bccd5657f.png","price":0.0,"typeId":23,"version":0,"watchDesc":"04ac774bccd5657f.di"}
 */
data class WatchFaceBean(
    var binUrl:String,
    var hardwareVersion:String,
    var name:String,
    var preImageUrl:String
)
